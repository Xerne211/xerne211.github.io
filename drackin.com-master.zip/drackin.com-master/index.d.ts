declare module "weather-js";
declare module "github-lang-colors"